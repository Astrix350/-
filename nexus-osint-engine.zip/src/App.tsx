import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI } from "@google/genai";
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { 
  Search, Phone, User, MapPin, Globe, ShieldAlert, 
  Loader2, History, Info, ExternalLink, Mail, 
  AtSign, Send, Fingerprint, Activity, Terminal,
  ShieldCheck, Zap, Copy, Share2, AlertTriangle,
  CheckCircle2, BarChart3, Download, MessageSquare, FileText,
  Camera, Cpu, Briefcase, CreditCard, FlaskConical, Layers,
  FileSearch, Lock, Key, Eye, EyeOff, Trash2, Filter,
  ArrowRightLeft, FileJson, FileType, FileSpreadsheet
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

// Initialize Gemini API
const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

type SearchType = 'phone' | 'email' | 'telegram' | 'ip' | 'username' | 'domain' | 'crypto' | 'vehicle' | 'face' | 'mac' | 'company' | 'passport' | 'auto';
type Language = 'ru' | 'en';

const translations = {
  ru: {
    title: 'Nexus OSINT',
    subtitle: 'Deep Intelligence Engine',
    nodes: 'Узлы: 1,242 Активно',
    version: 'v3.0 Ultra Deep Scan',
    heroTitle: 'НАЙДИ <span class="text-blue-500">ЛЮБОГО</span><br />ГДЕ УГОДНО.',
    heroDesc: 'Профессиональный инструмент для анализа цифровой личности. Поиск по всем слоям веба.',
    autoDetect: 'Авто-определение',
    phone: 'Телефон',
    email: 'Почта',
    telegram: 'Телеграм',
    ip: 'IP Адрес',
    username: 'Никнейм',
    domain: 'Домен/Сайт',
    crypto: 'Крипто-кошелек',
    vehicle: 'Госномер РФ',
    face: 'Лицо/Фото',
    mac: 'MAC/BSSID',
    company: 'Компания/ИНН',
    passport: 'Паспорт/ID',
    placeholderPhone: '+7 (999) 000-00-00',
    placeholderEmail: 'example@mail.com',
    placeholderTelegram: '@username',
    placeholderIp: '8.8.8.8',
    placeholderUsername: 'ivan_ivanov',
    placeholderDomain: 'google.com',
    placeholderCrypto: '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa',
    placeholderVehicle: 'А777АА77',
    placeholderAuto: 'Введите идентификатор...',
    deepScan: 'Глубокий поиск',
    scanDepth: 'Глубина сканирования',
    depthSurface: 'Поверхностная',
    depthDeep: 'Глубокая',
    depthUltra: 'Ультра (AI)',
    liveFeed: 'Глобальный поток активности',
    starred: 'Избранные дела',
    exportJson: 'Экспорт JSON',
    connectionGraph: 'Граф связей объекта',
    leakDetection: 'Утечки в Dark Web',
    leaksFound: 'Обнаружены совпадения в базах',
    noLeaks: 'Утечек не обнаружено',
    errorMinChars: 'Введите хотя бы 3 символа для поиска',
    errorGeneral: 'Ошибка при выполнении глубокого сканирования. Попробуйте изменить запрос.',
    scanningTitle: 'Сканирование сетевых уровней',
    scanningSubtitle: 'Доступ к глобальным базам данных',
    reportTitle: 'Отчет разведки',
    decryptedOutput: 'Расшифрованные данные анализа',
    threatAssessment: 'Оценка угроз',
    riskLevel: 'Уровень риска',
    score: 'Баллы',
    riskLow: 'Объект имеет низкий уровень цифровой опасности. Подозрительных связей не обнаружено.',
    riskMedium: 'Обнаружены умеренные риски. Рекомендуется дополнительная ручная проверка.',
    riskHigh: 'ВНИМАНИЕ: Высокий риск. Объект может быть связан с вредоносной или мошеннической деятельностью.',
    riskDetailsLabel: 'Детализация рисков',
    intelligenceSources: 'Источники данных',
    noSources: 'Прямых ссылок не найдено',
    recentInvestigations: 'Последние расследования',
    clearArchives: 'Очистить архивы',
    footerDesc: 'Продвинутый многовекторный интеллект-движок для авторизованных цифровых расследований и оценки рисков.',
    engineVersion: 'Движок v3.0.4-Stable',
    copySuccess: 'Скопировано в буфер обмена',
    copyReport: 'Копировать отчет',
    downloadPdf: 'Скачать PDF',
    downloadTxt: 'Скачать TXT',
    openTelegram: 'Открыть Telegram',
    googleSearch: 'Поиск в Google',
    tabSummary: 'Сводка',
    tabGraph: 'Граф связей',
    tabThreat: 'Угрозы',
    tabSources: 'Источники',
    tabPersona: 'Психопрофиль AI',
    labTitle: 'Nexus Lab: Спецсредства',
    labDorks: 'Конструктор Dorks',
    labMetadata: 'Анализ метаданных',
    labHeaders: 'Анализатор заголовков',
    labPassword: 'Проверка паролей',
    monitorTitle: 'Dark Web Мониторинг',
    monitorActive: 'Мониторинг активен',
    compareTitle: 'Сравнение дел',
    exportCsv: 'Экспорт в CSV'
  },
  en: {
    title: 'Nexus OSINT',
    subtitle: 'Deep Intelligence Engine',
    nodes: 'Nodes: 1,242 Active',
    version: 'v3.0 Ultra Deep Scan',
    heroTitle: 'FIND <span class="text-blue-500">ANYONE</span><br />ANYWHERE.',
    heroDesc: 'Professional digital identity analysis tool. Search across all web layers.',
    autoDetect: 'Auto-Detect',
    phone: 'Phone',
    email: 'Email',
    telegram: 'Telegram',
    ip: 'IP Address',
    username: 'Username',
    domain: 'Domain/Web',
    crypto: 'Crypto Wallet',
    vehicle: 'Vehicle Plate',
    face: 'Face/Photo',
    mac: 'MAC/BSSID',
    company: 'Company/BIN',
    passport: 'Passport/ID',
    placeholderPhone: '+1 (555) 000-00-00',
    placeholderEmail: 'example@mail.com',
    placeholderTelegram: '@username',
    placeholderIp: '8.8.8.8',
    placeholderUsername: 'johndoe_99',
    placeholderDomain: 'example.com',
    placeholderCrypto: '0x71C765... (ETH/BTC)',
    placeholderVehicle: 'ABC-1234',
    placeholderAuto: 'Enter identifier...',
    deepScan: 'Deep Scan',
    scanDepth: 'Scan Depth',
    depthSurface: 'Surface',
    depthDeep: 'Deep',
    depthUltra: 'Ultra (AI)',
    liveFeed: 'Global Activity Feed',
    starred: 'Starred Cases',
    exportJson: 'Export JSON',
    connectionGraph: 'Entity Connection Graph',
    leakDetection: 'Dark Web Leaks',
    leaksFound: 'Matches found in databases',
    noLeaks: 'No leaks detected',
    errorMinChars: 'Enter at least 3 characters to search',
    errorGeneral: 'Error performing deep scan. Please try a different query.',
    scanningTitle: 'Scanning Network Layers',
    scanningSubtitle: 'Accessing Global Databases',
    reportTitle: 'Intelligence Report',
    decryptedOutput: 'Decrypted Analysis Output',
    threatAssessment: 'Threat Assessment',
    riskLevel: 'Risk Level',
    score: 'Score',
    riskLow: 'The object has a low level of digital danger. No suspicious connections found.',
    riskMedium: 'Moderate risks detected. Additional manual verification is recommended.',
    riskHigh: 'WARNING: High Risk. The object may be associated with malicious or fraudulent activity.',
    riskDetailsLabel: 'Risk Details',
    intelligenceSources: 'Intelligence Sources',
    noSources: 'No direct evidence links',
    recentInvestigations: 'Recent Investigations',
    clearArchives: 'Clear Archives',
    footerDesc: 'Advanced multi-vector intelligence engine for authorized digital investigations and risk assessment.',
    engineVersion: 'Engine v3.0.4-Stable',
    copySuccess: 'Copied to clipboard',
    copyReport: 'Copy Report',
    downloadPdf: 'Download PDF',
    downloadTxt: 'Download TXT',
    openTelegram: 'Open Telegram',
    googleSearch: 'Google Search',
    tabSummary: 'Summary',
    tabGraph: 'Connection Graph',
    tabThreat: 'Threats',
    tabSources: 'Sources',
    tabPersona: 'AI Psychoprofile',
    labTitle: 'Nexus Lab: Special Tools',
    labDorks: 'Dorks Constructor',
    labMetadata: 'Metadata Analysis',
    labHeaders: 'Header Analyzer',
    labPassword: 'Password Checker',
    monitorTitle: 'Dark Web Monitoring',
    monitorActive: 'Monitoring active',
    compareTitle: 'Case Comparison',
    exportCsv: 'Export to CSV'
  }
};

interface SearchResult {
  id: string;
  query: string;
  type: SearchType;
  summary: string;
  summarySections: { title: string; content: string }[];
  sources: { uri: string; title: string }[];
  timestamp: string;
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  riskScore: number; // 0-100
  riskDetails?: string;
  isStarred?: boolean;
}

export default function App() {
  const [query, setQuery] = useState('');
  const [searchType, setSearchType] = useState<SearchType>('auto');
  const [isSearching, setIsSearching] = useState(false);
  const [result, setResult] = useState<SearchResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<SearchResult[]>([]);
  const [scanDepth, setScanDepth] = useState<'surface' | 'deep' | 'ultra'>('deep');
  const [liveEvents, setLiveEvents] = useState<{ id: string; text: string; time: string }[]>([]);
  const [showStarredOnly, setShowStarredOnly] = useState(false);
  const [activeReportTab, setActiveReportTab] = useState<'summary' | 'graph' | 'threat' | 'sources' | 'persona'>('summary');
  const [showLab, setShowLab] = useState(false);
  const [compareMode, setCompareMode] = useState(false);
  const [compareItems, setCompareItems] = useState<string[]>([]);

  useEffect(() => {
    const events = [
      "Node 042: Scanning VK API...",
      "Node 118: Decrypting Telegram Metadata...",
      "Node 009: Accessing DarkWeb fragment 0x4F...",
      "Node 256: IP Geolocation mapping...",
      "Node 077: Whois database query...",
      "Node 102: Blockchain ledger analysis...",
    ];
    
    const interval = setInterval(() => {
      const newEvent = {
        id: Math.random().toString(36).substr(2, 9),
        text: events[Math.floor(Math.random() * events.length)],
        time: new Date().toLocaleTimeString(),
      };
      setLiveEvents(prev => [newEvent, ...prev].slice(0, 5));
    }, 4000);
    
    return () => clearInterval(interval);
  }, []);
  const [lang, setLang] = useState<Language>('ru');
  const reportRef = useRef<HTMLDivElement>(null);

  const t = translations[lang];

  // Load history from localStorage
  useEffect(() => {
    const savedHistory = localStorage.getItem('osint_lookup_history_v2');
    if (savedHistory) {
      try {
        setHistory(JSON.parse(savedHistory));
      } catch (e) {
        console.error("Failed to parse history", e);
      }
    }
  }, []);

  const addToHistory = (newResult: SearchResult) => {
    const updatedHistory = [newResult, ...history.filter(h => h.query !== newResult.query)].slice(0, 5);
    setHistory(updatedHistory);
    localStorage.setItem('osint_lookup_history_v2', JSON.stringify(updatedHistory));
  };

  const detectType = (val: string): SearchType => {
    if (val.includes('@') && val.includes('.')) return 'email';
    if (val.startsWith('@') || (!val.includes('@') && /^[a-zA-Z][a-zA-Z0-9_]{4,31}$/.test(val))) return 'telegram';
    if (/^[\d\+\-\(\) ]+$/.test(val) && val.length > 5) return 'phone';
    if (/^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$/.test(val)) return 'ip';
    if (/^[a-zA-Z0-9_]{3,30}$/.test(val)) return 'username';
    if (/^[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}$/.test(val)) return 'domain';
    if (/^(0x)?[0-9a-fA-F]{40}$/.test(val) || /^[13][a-km-zA-HJ-NP-Z1-9]{25,34}$/.test(val)) return 'crypto';
    if (/^[а-яА-Я]\d{3}[а-яА-Я]{2}\d{2,3}$/.test(val)) return 'vehicle';
    return 'auto';
  };

  const handleSearch = async (e?: React.FormEvent, targetQuery?: string) => {
    if (e) e.preventDefault();
    const finalQuery = targetQuery || query;
    const finalType = searchType === 'auto' ? detectType(finalQuery) : searchType;
    
    if (!finalQuery || finalQuery.length < 3) {
      setError(t.errorMinChars);
      return;
    }

    setIsSearching(true);
    setError(null);
    setResult(null);

    try {
      const prompt = `PERFORM MAXIMUM DEEP OSINT ANALYSIS (LEVEL: EXPERT). 
        Request Type: ${finalType}
        Query: ${finalQuery}
        Scan Depth: ${scanDepth.toUpperCase()}

        Your task is to extract EVERY bit of information from ALL available layers of the internet (Surface Web, Deep Web fragments, Social Graphs).
        
        SEARCH REQUIREMENTS BY TYPE:
        - PHONE/EMAIL/TELEGRAM: Find social profiles, leaks, mentions, linked accounts.
        - IP: Geolocation, ISP, open ports, historical usage.
        - USERNAME: Cross-platform search (GitHub, Twitter, Reddit, etc.), bio analysis.
        - DOMAIN: Whois, DNS, subdomains, server info, historical snapshots.
        - CRYPTO: Transaction history (simulated), wallet balance (simulated), linked services.
        - VEHICLE: Owner info (simulated), accident history, registration status.
        - FACE: If a URL is provided, simulate facial recognition across social media.
        - MAC/BSSID: Geolocation of Wi-Fi access points or devices.
        - COMPANY: Business records, directors, financial links, tax IDs.
        - PASSPORT: Simulate verification of ID documents (validity, leaks).

        GENERAL REQUIREMENTS:
        1. MESSENGERS: Find ALL mentions in Telegram (channels, chats, bots), WhatsApp, Viber.
        2. SOCIAL NETWORKS: VK, Instagram, FB, LinkedIn, Twitter, TikTok.
        3. CONTACTS: How is this person listed by others? (GetContact, Eyecon and similar public data).
        4. ADS: Avito, Youla, Auto.ru, eBay, Craigslist.
        5. LEAKS: Check for presence in known public dumps.
        6. GEOLOCATION: Provide detailed geolocation if applicable.
        7. RISKS: Assess the probability of fraud, spam or connection with gray schemes.

        RESPONSE FORMAT:
        - Use Markdown.
        - Structure your response into clear sections using '###' headers. 
        - Possible sections: General Information, Social Media Presence, Data Leaks & Breaches, Network Infrastructure, Geolocation Data, AI Persona Analysis, etc.
        - Make links CLICKABLE (use [name](url) format).
        - At the end, add a "RISK-METRIC" section with a score from 0 to 100.
        - If the risk is not low, add a "RISK-DETAILS" section with specific reasons.
        
        Respond in ${lang === 'ru' ? 'Russian' : 'English'}. Be as detailed as possible.`;

      const response = await genAI.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          tools: [{ googleSearch: {} }],
        },
      });

      const text = response.text || '';
      
      // Parse summary into sections
      const sections: { title: string; content: string }[] = [];
      const rawSections = text.split(/###\s+/);
      
      rawSections.forEach((section, index) => {
        if (index === 0 && !section.trim()) return;
        
        const lines = section.trim().split('\n');
        const title = index === 0 && !text.startsWith('###') ? (lang === 'ru' ? 'Общая информация' : 'General Information') : lines[0].trim();
        const content = index === 0 && !text.startsWith('###') ? section.trim() : lines.slice(1).join('\n').trim();
        
        if (title && content && !title.includes('RISK-METRIC') && !title.includes('РИСК-МЕТРИКА')) {
          sections.push({ title, content });
        }
      });

      // If no sections were parsed, put everything in one
      if (sections.length === 0) {
        sections.push({ 
          title: lang === 'ru' ? 'Результаты поиска' : 'Search Results', 
          content: text.replace(/RISK-METRIC[\s\S]*$/i, '').replace(/РИСК-МЕТРИКА[\s\S]*$/i, '').trim() 
        });
      }

      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      const sources = chunks?.map(c => ({
        uri: c.web?.uri || '',
        title: c.web?.title || 'Источник'
      })).filter(s => s.uri) || [];

      // Extract risk score from text if possible, else random for demo
      const riskMatch = text.match(/RISK-METRIC.*?(\d+)/i) || text.match(/РИСК-МЕТРИКА.*?(\d+)/i);
      const riskScore = riskMatch ? parseInt(riskMatch[1]) : Math.floor(Math.random() * 40);
      
      // Extract risk details
      const riskDetailsMatch = text.match(/RISK-DETAILS([\s\S]*?)$|РИСК-ДЕТАЛИ([\s\S]*?)$|РИСК-ПОДРОБНОСТИ([\s\S]*?)$/i);
      const riskDetails = riskDetailsMatch ? riskDetailsMatch[0].replace(/RISK-DETAILS|РИСК-ДЕТАЛИ|РИСК-ПОДРОБНОСТИ/i, '').trim() : undefined;

      let riskLevel: SearchResult['riskLevel'] = 'low';
      if (riskScore > 80) riskLevel = 'critical';
      else if (riskScore > 60) riskLevel = 'high';
      else if (riskScore > 30) riskLevel = 'medium';

      const newResult: SearchResult = {
        id: Math.random().toString(36).substr(2, 9),
        query: finalQuery,
        type: finalType,
        summary: text,
        summarySections: sections,
        sources: sources,
        timestamp: new Date().toLocaleString(lang === 'ru' ? 'ru-RU' : 'en-US'),
        riskLevel,
        riskScore,
        riskDetails,
        isStarred: false
      };

      setResult(newResult);
      addToHistory(newResult);
    } catch (err) {
      console.error(err);
      setError(t.errorGeneral);
    } finally {
      setIsSearching(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    // Simple toast simulation
    alert(t.copySuccess);
  };

  const getQuickLinks = (q: string, type: SearchType) => {
    const links = [];
    if (type === 'phone') {
      links.push({ name: 'WhatsApp', url: `https://wa.me/${q.replace(/\D/g, '')}`, icon: <MessageSquare size={14} /> });
      links.push({ name: 'Telegram', url: `https://t.me/${q.replace(/\D/g, '')}`, icon: <Send size={14} /> });
    } else if (type === 'telegram') {
      links.push({ name: 'Telegram', url: `https://t.me/${q.replace('@', '')}`, icon: <Send size={14} /> });
    } else if (type === 'email') {
      links.push({ name: 'Email Search', url: `https://hunter.io/email-verifier/${q}`, icon: <Mail size={14} /> });
    } else if (type === 'ip') {
      links.push({ name: 'IP Geolocation', url: `https://www.iplocation.net/search?wt_search=${q}`, icon: <Globe size={14} /> });
      links.push({ name: 'Google Maps', url: `https://www.google.com/maps/search/${q}`, icon: <MapPin size={14} /> });
    }
    links.push({ name: t.googleSearch, url: `https://www.google.com/search?q=${encodeURIComponent(q)}`, icon: <Search size={14} /> });
    return links;
  };

  const downloadPdf = async () => {
    if (!reportRef.current || !result) return;

    try {
      const element = reportRef.current;
      
      // Create a clone to avoid modifying the actual UI during capture
      const canvas = await html2canvas(element, {
        backgroundColor: '#050506',
        scale: 2, // Higher scale for better quality
        useCORS: true,
        allowTaint: true,
        logging: false,
        onclone: (clonedDoc) => {
          // You can perform additional cleanup on the cloned document here if needed
          const clonedElement = clonedDoc.getElementById('report-container');
          if (clonedElement) {
            clonedElement.style.padding = '40px';
          }
        }
      });
      
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'px',
        format: [canvas.width / 2, canvas.height / 2]
      });

      pdf.addImage(imgData, 'PNG', 0, 0, canvas.width / 2, canvas.height / 2);
      pdf.save(`Nexus_OSINT_Report_${result.query.replace(/[^a-z0-9]/gi, '_')}.pdf`);
    } catch (err) {
      console.error('PDF generation error:', err);
      alert('Error generating PDF. Please try again.');
    }
  };

  const downloadTxt = () => {
    if (!result) return;
    
    const content = `
NEXUS OSINT INTELLIGENCE REPORT
-------------------------------
Query: ${result.query}
Type: ${result.type.toUpperCase()}
Timestamp: ${result.timestamp}
Risk Level: ${result.riskLevel.toUpperCase()}
Risk Score: ${result.riskScore}/100

SUMMARY:
${result.summary}

${result.riskDetails ? `RISK DETAILS:\n${result.riskDetails}\n` : ''}
SOURCES:
${result.sources.map(s => `- ${s.title}: ${s.uri}`).join('\n')}

Generated by Nexus OSINT Engine
    `.trim();

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Nexus_OSINT_Report_${result.query.replace(/[^a-z0-9]/gi, '_')}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const downloadJson = () => {
    if (!result) return;
    const blob = new Blob([JSON.stringify(result, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Nexus_OSINT_Report_${result.query.replace(/[^a-z0-9]/gi, '_')}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const downloadCsv = () => {
    if (!result) return;
    
    const headers = ['Field', 'Value'];
    const rows = [
      ['Query', result.query],
      ['Type', result.type],
      ['Timestamp', result.timestamp],
      ['Risk Level', result.riskLevel],
      ['Risk Score', result.riskScore.toString()],
      ['Summary', result.summary.replace(/"/g, '""')]
    ];
    
    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Nexus_OSINT_Report_${result.query.replace(/[^a-z0-9]/gi, '_')}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const toggleStar = (id: string) => {
    const updatedHistory = history.map(item => 
      item.id === id ? { ...item, isStarred: !item.isStarred } : item
    );
    setHistory(updatedHistory);
    localStorage.setItem('osint_lookup_history_v2', JSON.stringify(updatedHistory));
    if (result && result.id === id) {
      setResult({ ...result, isStarred: !result.isStarred });
    }
  };

  return (
    <div className="min-h-screen bg-[#050506] text-[#E1E1E6] font-sans selection:bg-blue-500/30">
      {/* Background Grid Effect */}
      <div className="fixed inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:30px_30px] pointer-events-none" />
      <div className="fixed inset-0 bg-radial-at-t from-blue-600/10 via-transparent to-transparent pointer-events-none" />

      {/* Header */}
      <header className="relative z-10 border-b border-white/5 bg-[#050506]/80 backdrop-blur-2xl">
        <div className="max-w-6xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-tr from-blue-600 to-cyan-400 rounded-xl flex items-center justify-center shadow-2xl shadow-blue-500/40">
              <Fingerprint size={22} className="text-white" />
            </div>
            <div>
              <h1 className="font-black text-xl tracking-tighter text-white uppercase italic">{t.title}</h1>
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse" />
                <span className="text-[9px] font-black uppercase tracking-[0.2em] text-blue-500/80">{t.subtitle}</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={() => setLang(lang === 'ru' ? 'en' : 'ru')}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 border border-white/10 text-[10px] font-black text-white uppercase tracking-widest hover:bg-white/10 transition-all"
            >
              <Globe size={12} className="text-blue-500" />
              <span>{lang === 'ru' ? 'EN' : 'RU'}</span>
            </button>
            <div className="hidden md:flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 border border-white/10 text-[10px] font-bold text-gray-400 uppercase tracking-widest">
              <Activity size={12} className="text-blue-500" />
              <span>{t.nodes}</span>
            </div>
          </div>
        </div>
      </header>

      <main className="relative z-10 max-w-6xl mx-auto px-6 py-12 md:py-24">
        {/* Search Section */}
        <section className="max-w-3xl mx-auto mb-20">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-[10px] font-black uppercase tracking-widest mb-6">
              <Zap size={12} />
              <span>{t.version}</span>
            </div>
            <h2 
              className="text-5xl md:text-7xl font-black tracking-tighter text-white mb-6 leading-[0.9]"
              dangerouslySetInnerHTML={{ __html: t.heroTitle }}
            />
            <p className="text-gray-500 text-lg max-w-lg mx-auto font-medium">
              {t.heroDesc}
            </p>
          </motion.div>

          {/* Search Type Selector */}
          <div className="flex flex-wrap justify-center gap-2 mb-8">
            {(['auto', 'phone', 'email', 'telegram', 'ip', 'username', 'domain', 'crypto', 'vehicle', 'face', 'mac', 'company', 'passport'] as SearchType[]).map((t_key) => (
              <button
                key={t_key}
                type="button"
                onClick={() => setSearchType(t_key)}
                className={`px-5 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-[0.15em] transition-all border ${
                  searchType === t_key 
                  ? 'bg-blue-600 border-blue-400 text-white shadow-2xl shadow-blue-600/40 scale-105' 
                  : 'bg-white/5 border-white/10 text-gray-500 hover:bg-white/10 hover:text-gray-300'
                }`}
              >
                {t_key === 'auto' && t.autoDetect}
                {t_key === 'phone' && t.phone}
                {t_key === 'email' && t.email}
                {t_key === 'telegram' && t.telegram}
                {t_key === 'ip' && t.ip}
                {t_key === 'username' && t.username}
                {t_key === 'domain' && t.domain}
                {t_key === 'crypto' && t.crypto}
                {t_key === 'vehicle' && t.vehicle}
                {t_key === 'face' && t.face}
                {t_key === 'mac' && t.mac}
                {t_key === 'company' && t.company}
                {t_key === 'passport' && t.passport}
              </button>
            ))}
          </div>

          {/* Scan Depth Selector */}
          <div className="flex justify-center items-center gap-6 mb-12">
            <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">{t.scanDepth}</span>
            <div className="flex gap-2 p-1 bg-white/5 rounded-2xl border border-white/10">
              {(['surface', 'deep', 'ultra'] as const).map((depth) => (
                <button
                  key={depth}
                  onClick={() => setScanDepth(depth)}
                  className={`px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${
                    scanDepth === depth 
                    ? 'bg-blue-500 text-white shadow-lg' 
                    : 'text-gray-500 hover:text-gray-300'
                  }`}
                >
                  {depth === 'surface' && t.depthSurface}
                  {depth === 'deep' && t.depthDeep}
                  {depth === 'ultra' && t.depthUltra}
                </button>
              ))}
            </div>
          </div>

          <form onSubmit={handleSearch} className="relative group">
            <div className="absolute inset-y-0 left-6 flex items-center pointer-events-none text-gray-600 group-focus-within:text-blue-500 transition-colors">
              {searchType === 'phone' && <Phone size={22} />}
              {searchType === 'email' && <Mail size={22} />}
              {searchType === 'telegram' && <AtSign size={22} />}
              {searchType === 'ip' && <Globe size={22} />}
              {searchType === 'username' && <User size={22} />}
              {searchType === 'domain' && <Globe size={22} />}
              {searchType === 'crypto' && <Fingerprint size={22} />}
              {searchType === 'vehicle' && <Activity size={22} />}
              {(searchType === 'auto' || !searchType) && <Search size={22} />}
            </div>
            <input
              type="text"
              placeholder={
                searchType === 'phone' ? t.placeholderPhone :
                searchType === 'email' ? t.placeholderEmail :
                searchType === 'telegram' ? t.placeholderTelegram :
                searchType === 'ip' ? t.placeholderIp :
                t.placeholderAuto
              }
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="w-full bg-white/[0.02] border border-white/10 rounded-[2rem] py-6 pl-16 pr-44 text-white placeholder:text-gray-700 focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500/50 transition-all text-xl font-bold shadow-2xl"
            />
            <button
              type="submit"
              disabled={isSearching}
              className="absolute right-3 top-3 bottom-3 bg-blue-600 hover:bg-blue-500 disabled:bg-gray-800 text-white px-10 rounded-[1.5rem] font-black uppercase tracking-widest text-xs transition-all flex items-center gap-2 shadow-xl shadow-blue-600/20 active:scale-95"
            >
              {isSearching ? <Loader2 className="animate-spin" size={20} /> : (
                <>
                  <Zap size={18} />
                  <span>{t.deepScan}</span>
                </>
              )}
            </button>
          </form>
          
          {error && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-6 text-red-400 text-xs font-bold flex items-center gap-3 px-6 py-4 bg-red-500/5 border border-red-500/10 rounded-2xl"
            >
              <ShieldAlert size={18} /> {error}
            </motion.div>
          )}
        </section>

        {/* Results Section */}
        <AnimatePresence mode="wait">
          {isSearching ? (
            <motion.div
              key="searching"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center justify-center py-32"
            >
              <div className="relative mb-10">
                <div className="absolute inset-0 bg-blue-600 blur-[100px] opacity-30 animate-pulse" />
                <div className="w-24 h-24 border-4 border-blue-500/20 border-t-blue-500 rounded-full animate-spin relative z-10" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <Fingerprint size={32} className="text-blue-500 animate-pulse" />
                </div>
              </div>
              <div className="text-center space-y-3">
                <p className="text-2xl font-black text-white tracking-tighter uppercase italic">{t.scanningTitle}</p>
                <div className="flex items-center justify-center gap-2 text-gray-600 font-mono text-[10px] uppercase tracking-[0.3em]">
                  <span className="animate-bounce">.</span>
                  <span className="animate-bounce [animation-delay:0.2s]">.</span>
                  <span className="animate-bounce [animation-delay:0.4s]">.</span>
                  <span>{t.scanningSubtitle}</span>
                  <span className="animate-bounce">.</span>
                  <span className="animate-bounce [animation-delay:0.2s]">.</span>
                  <span className="animate-bounce [animation-delay:0.4s]">.</span>
                </div>
              </div>
            </motion.div>
          ) : result ? (
            <motion.div
              key="result"
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              className="grid grid-cols-1 lg:grid-cols-4 gap-8"
            >
              {/* Main Content */}
              <div className="lg:col-span-3 space-y-8" ref={reportRef} id="report-container">
                <div className="bg-white/[0.02] border border-white/5 rounded-[2.5rem] p-8 md:p-12 backdrop-blur-3xl shadow-2xl relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none">
                    <Terminal size={120} />
                  </div>

                  <div className="flex flex-wrap items-start justify-between gap-6 mb-12 relative z-10">
                    <div className="flex items-start gap-6">
                      <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-600/20 to-cyan-400/20 border border-blue-500/30 flex items-center justify-center text-blue-400 shadow-xl">
                        {result.type === 'phone' && <Phone size={32} />}
                        {result.type === 'email' && <Mail size={32} />}
                        {result.type === 'telegram' && <Send size={32} />}
                        {result.type === 'auto' && <Fingerprint size={32} />}
                      </div>
                      <div className="space-y-4">
                        <div className="flex items-center gap-3">
                          <span className="px-3 py-1 bg-blue-600/20 text-blue-400 text-[10px] font-black uppercase tracking-[0.2em] border border-blue-500/30 rounded-lg">
                            {t.reportTitle}
                          </span>
                          <span className="text-gray-600 text-[10px] font-mono uppercase tracking-widest">{result.timestamp}</span>
                        </div>
                        <h3 className="text-4xl md:text-5xl font-black text-white tracking-tighter break-all leading-none">
                          {result.query}
                        </h3>
                        <div className="flex flex-wrap gap-2">
                          {getQuickLinks(result.query, result.type).map((link, i) => (
                            <a 
                              key={i} 
                              href={link.url} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="flex items-center gap-2 px-3 py-1.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-[10px] font-bold text-gray-400 transition-all"
                            >
                              {link.icon}
                              {link.name}
                            </a>
                          ))}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex flex-col items-end gap-4">
                      <div className="flex gap-2">
                        <button 
                          onClick={() => copyToClipboard(result.summary)}
                          className="p-4 bg-white/5 hover:bg-white/10 rounded-2xl text-gray-400 border border-white/10 transition-all"
                          title={t.copyReport}
                        >
                          <Copy size={20} />
                        </button>
                        <button 
                          onClick={downloadPdf}
                          className="p-4 bg-white/5 hover:bg-white/10 rounded-2xl text-gray-400 border border-white/10 transition-all"
                          title={t.downloadPdf}
                        >
                          <Download size={20} />
                        </button>
                        <button 
                          onClick={downloadTxt}
                          className="p-4 bg-white/5 hover:bg-white/10 rounded-2xl text-gray-400 border border-white/10 transition-all"
                          title={t.downloadTxt}
                        >
                          <FileText size={20} />
                        </button>
                        <button 
                          onClick={downloadJson}
                          className="p-4 bg-white/5 hover:bg-white/10 rounded-2xl text-gray-400 border border-white/10 transition-all"
                          title={t.exportJson}
                        >
                          <Terminal size={20} />
                        </button>
                        <button 
                          onClick={downloadCsv}
                          className="p-4 bg-white/5 hover:bg-white/10 rounded-2xl text-gray-400 border border-white/10 transition-all"
                          title={t.exportCsv}
                        >
                          <FileSpreadsheet size={20} />
                        </button>
                        <button 
                          onClick={() => toggleStar(result.id)}
                          className={`p-4 rounded-2xl border transition-all ${result.isStarred ? 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20' : 'bg-white/5 hover:bg-white/10 text-gray-400 border-white/10'}`}
                          title={t.starred}
                        >
                          <Zap size={20} fill={result.isStarred ? "currentColor" : "none"} />
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Tab Navigation */}
                  <div className="flex items-center gap-2 mb-8 bg-white/5 p-1.5 rounded-2xl border border-white/10 w-fit">
                    {[
                      { id: 'summary', label: t.tabSummary, icon: <Terminal size={14} /> },
                      { id: 'graph', label: t.tabGraph, icon: <Activity size={14} /> },
                      { id: 'threat', label: t.tabThreat, icon: <ShieldAlert size={14} /> },
                      { id: 'persona', label: t.tabPersona, icon: <User size={14} /> },
                      { id: 'sources', label: t.tabSources, icon: <Globe size={14} /> }
                    ].map((tab) => (
                      <button
                        key={tab.id}
                        onClick={() => setActiveReportTab(tab.id as any)}
                        className={`flex items-center gap-2 px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                          activeReportTab === tab.id 
                          ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20' 
                          : 'text-gray-500 hover:text-gray-300 hover:bg-white/5'
                        }`}
                      >
                        {tab.icon}
                        {tab.label}
                      </button>
                    ))}
                  </div>

                  <AnimatePresence mode="wait">
                    {activeReportTab === 'summary' && (
                      <motion.div 
                        key="summary"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        className="relative z-10 space-y-6"
                      >
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                          {(result.summarySections || []).map((section, idx) => (
                            <motion.div 
                              key={idx}
                              initial={{ opacity: 0, scale: 0.95 }}
                              animate={{ opacity: 1, scale: 1 }}
                              transition={{ delay: idx * 0.1 }}
                              className="bg-black/40 rounded-3xl p-8 border border-white/5 shadow-inner group hover:border-blue-500/20 transition-all"
                            >
                              <div className="flex items-center gap-3 mb-6 text-blue-500/40 border-b border-white/5 pb-4 group-hover:text-blue-500/60 transition-colors">
                                <Terminal size={16} />
                                <span className="text-[10px] uppercase font-black tracking-[0.3em]">{section.title}</span>
                              </div>
                              
                              <div className="markdown-body prose prose-invert max-w-none prose-p:text-gray-300 prose-headings:text-white prose-a:text-blue-400 prose-a:no-underline hover:prose-a:underline prose-strong:text-blue-200 text-xs leading-relaxed">
                                <ReactMarkdown 
                                  remarkPlugins={[remarkGfm]}
                                  components={{
                                    a: ({ node, ...props }) => (
                                      <a 
                                        {...props} 
                                        target="_blank" 
                                        rel="noopener noreferrer" 
                                        className="inline-flex items-center gap-1 text-blue-400 hover:text-blue-300 transition-colors font-bold"
                                      >
                                        {props.children}
                                        <ExternalLink size={10} />
                                      </a>
                                    )
                                  }}
                                >
                                  {section.content}
                                </ReactMarkdown>
                              </div>
                            </motion.div>
                          ))}
                          
                          {(!result.summarySections || result.summarySections.length === 0) && (
                            <div className="col-span-full bg-black/40 rounded-3xl p-8 border border-white/5 shadow-inner">
                              <div className="flex items-center gap-3 mb-6 text-blue-500/40 border-b border-white/5 pb-4">
                                <Terminal size={16} />
                                <span className="text-[10px] uppercase font-black tracking-[0.3em]">{t.decryptedOutput}</span>
                              </div>
                              <div className="markdown-body prose prose-invert max-w-none prose-p:text-gray-300 prose-headings:text-white prose-a:text-blue-400 prose-a:no-underline hover:prose-a:underline prose-strong:text-blue-200">
                                <ReactMarkdown 
                                  remarkPlugins={[remarkGfm]}
                                  components={{
                                    a: ({ node, ...props }) => (
                                      <a 
                                        {...props} 
                                        target="_blank" 
                                        rel="noopener noreferrer" 
                                        className="inline-flex items-center gap-1 text-blue-400 hover:text-blue-300 transition-colors font-bold"
                                      >
                                        {props.children}
                                        <ExternalLink size={10} />
                                      </a>
                                    )
                                  }}
                                >
                                  {result.summary}
                                </ReactMarkdown>
                              </div>
                            </div>
                          )}
                        </div>
                      </motion.div>
                    )}

                    {activeReportTab === 'graph' && (
                      <motion.div 
                        key="graph"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        className="mt-0"
                      >
                        <div className="bg-black/40 rounded-[3rem] p-12 border border-white/5 relative overflow-hidden h-[500px] flex items-center justify-center">
                          <div className="absolute inset-0 opacity-10 pointer-events-none">
                            <div className="w-full h-full" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, rgba(59,130,246,0.15) 1px, transparent 0)', backgroundSize: '40px 40px' }} />
                          </div>
                          
                          <svg width="100%" height="100%" viewBox="0 0 800 400" className="relative z-10">
                            <defs>
                              <filter id="glow">
                                <feGaussianBlur stdDeviation="2.5" result="coloredBlur"/>
                                <feMerge>
                                  <feMergeNode in="coloredBlur"/>
                                  <feMergeNode in="SourceGraphic"/>
                                </feMerge>
                              </filter>
                            </defs>
                            
                            <motion.circle 
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              cx="400" cy="200" r="40" 
                              className="fill-blue-600/20 stroke-blue-500 stroke-2"
                              filter="url(#glow)"
                            />
                            <text x="400" y="205" textAnchor="middle" className="fill-white text-[10px] font-black uppercase tracking-tighter italic">ENTITY</text>
                            
                            {[
                              { x: 200, y: 100, label: 'SOCIAL' },
                              { x: 600, y: 100, label: 'NETWORK' },
                              { x: 200, y: 300, label: 'DATA' },
                              { x: 600, y: 300, label: 'LEAKS' },
                              { x: 400, y: 50, label: 'CLOUD' },
                              { x: 400, y: 350, label: 'GEO' }
                            ].map((node, i) => (
                              <g key={i}>
                                <motion.line 
                                  initial={{ pathLength: 0, opacity: 0 }}
                                  animate={{ pathLength: 1, opacity: 0.2 }}
                                  transition={{ delay: i * 0.2, duration: 1 }}
                                  x1="400" y1="200" x2={node.x} y2={node.y} 
                                  className="stroke-blue-500 stroke-1"
                                />
                                <motion.circle 
                                  initial={{ scale: 0 }}
                                  animate={{ scale: 1 }}
                                  transition={{ delay: i * 0.2 + 0.5 }}
                                  cx={node.x} cy={node.y} r="25" 
                                  className="fill-white/5 stroke-white/10 stroke-1"
                                />
                                <text x={node.x} y={node.y + 5} textAnchor="middle" className="fill-gray-500 text-[8px] font-black uppercase tracking-widest">{node.label}</text>
                              </g>
                            ))}
                            
                            {[0, 1, 2, 3, 4, 5].map((i) => (
                              <motion.circle
                                key={`p-${i}`}
                                r="2"
                                className="fill-blue-400"
                                animate={{
                                  cx: [400, [200, 600, 200, 600, 400, 400][i]],
                                  cy: [200, [100, 100, 300, 300, 50, 350][i]],
                                }}
                                transition={{
                                  duration: 2 + Math.random() * 2,
                                  repeat: Infinity,
                                  ease: "linear",
                                  delay: Math.random() * 2
                                }}
                              />
                            ))}
                          </svg>
                          
                          <div className="absolute bottom-8 right-8 flex items-center gap-2">
                            <div className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse" />
                            <span className="text-[8px] font-black text-blue-500/60 uppercase tracking-[0.2em] italic">Real-time mapping active</span>
                          </div>
                        </div>
                      </motion.div>
                    )}

                    {activeReportTab === 'threat' && (
                      <motion.div 
                        key="threat"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        className="grid grid-cols-1 md:grid-cols-2 gap-8"
                      >
                        <div className="bg-white/[0.02] border border-white/5 rounded-[2rem] p-8 backdrop-blur-3xl">
                          <h4 className="text-[10px] font-black text-gray-500 uppercase tracking-[0.3em] mb-8 flex items-center gap-2">
                            <BarChart3 size={14} /> {t.threatAssessment}
                          </h4>
                          
                          <div className="space-y-8">
                            <div className="relative h-4 w-full bg-white/5 rounded-full overflow-hidden border border-white/5">
                              <motion.div 
                                initial={{ width: 0 }}
                                animate={{ width: `${result.riskScore}%` }}
                                transition={{ duration: 1.5, ease: "easeOut" }}
                                className={`absolute inset-y-0 left-0 rounded-full ${
                                  result.riskLevel === 'low' ? 'bg-emerald-500' :
                                  result.riskLevel === 'medium' ? 'bg-yellow-500' :
                                  result.riskLevel === 'high' ? 'bg-orange-500' : 'bg-red-600'
                                } shadow-[0_0_20px_rgba(59,130,246,0.5)]`}
                              />
                            </div>
                            
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1">{t.riskLevel}</p>
                                <p className={`text-xl font-black uppercase italic ${
                                  result.riskLevel === 'low' ? 'text-emerald-400' :
                                  result.riskLevel === 'medium' ? 'text-yellow-400' :
                                  result.riskLevel === 'high' ? 'text-orange-400' : 'text-red-500'
                                }`}>
                                  {result.riskLevel}
                                </p>
                              </div>
                              <div className="text-right">
                                <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1">{t.score}</p>
                                <p className="text-3xl font-black text-white">{result.riskScore}<span className="text-xs text-gray-600">/100</span></p>
                              </div>
                            </div>

                            <div className={`p-4 rounded-2xl border ${
                              result.riskLevel === 'low' ? 'bg-emerald-500/5 border-emerald-500/10 text-emerald-500/80' :
                              result.riskLevel === 'medium' ? 'bg-yellow-500/5 border-yellow-500/10 text-yellow-500/80' :
                              'bg-red-500/5 border-red-500/10 text-red-500/80'
                            } text-[10px] font-bold leading-relaxed`}>
                              {result.riskLevel === 'low' && t.riskLow}
                              {result.riskLevel === 'medium' && t.riskMedium}
                              {(result.riskLevel === 'high' || result.riskLevel === 'critical') && t.riskHigh}
                            </div>
                          </div>
                        </div>

                        {result.riskDetails && result.riskLevel !== 'low' && (
                          <div className="bg-white/[0.02] border border-white/5 rounded-[2rem] p-8 backdrop-blur-3xl">
                            <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-8 flex items-center gap-2 italic">
                              <AlertTriangle size={14} className="text-orange-500" /> {t.riskDetailsLabel}
                            </p>
                            <div className="text-[11px] text-gray-400 leading-relaxed font-medium bg-white/5 p-6 rounded-3xl border border-white/5 h-[calc(100%-3rem)] overflow-y-auto custom-scrollbar">
                              <ReactMarkdown remarkPlugins={[remarkGfm]}>
                                {result.riskDetails}
                              </ReactMarkdown>
                            </div>
                          </div>
                        )}
                      </motion.div>
                    )}

                    {activeReportTab === 'persona' && (
                      <motion.div 
                        key="persona"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        className="bg-gradient-to-br from-blue-900/10 to-transparent border border-blue-500/10 rounded-[3rem] p-12 backdrop-blur-3xl relative overflow-hidden"
                      >
                        <div className="absolute top-0 right-0 p-12 opacity-5 pointer-events-none">
                          <User size={200} />
                        </div>
                        <div className="relative z-10">
                          <div className="flex items-center gap-4 mb-10">
                            <div className="p-4 bg-blue-500/20 rounded-2xl border border-blue-500/30">
                              <Activity size={32} className="text-blue-400" />
                            </div>
                            <div>
                              <h4 className="text-2xl font-black text-white tracking-tighter uppercase italic">{t.tabPersona}</h4>
                              <p className="text-[10px] font-black text-blue-500/60 uppercase tracking-[0.3em]">AI-Generated Psychological Profile</p>
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
                            {[
                              { label: 'Reliability', value: '84%', color: 'text-emerald-400' },
                              { label: 'Social Activity', value: 'High', color: 'text-blue-400' },
                              { label: 'Digital Footprint', value: 'Extensive', color: 'text-orange-400' }
                            ].map((stat, i) => (
                              <div key={i} className="bg-white/5 p-6 rounded-3xl border border-white/5">
                                <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-2">{stat.label}</p>
                                <p className={`text-3xl font-black ${stat.color} italic`}>{stat.value}</p>
                              </div>
                            ))}
                          </div>

                          <div className="prose prose-invert max-w-none text-gray-400 text-sm leading-relaxed font-medium bg-black/20 p-8 rounded-[2rem] border border-white/5">
                            <ReactMarkdown>
                              {result.summarySections.find(s => s.title.toLowerCase().includes('persona') || s.title.toLowerCase().includes('профиль'))?.content || 
                               (lang === 'ru' ? 'Анализ личности завершен. Объект проявляет высокую цифровую активность. Рекомендуется дальнейшее наблюдение за социальными связями.' : 'Persona analysis complete. Subject shows high digital activity. Further monitoring of social connections is recommended.')}
                            </ReactMarkdown>
                          </div>
                        </div>
                      </motion.div>
                    )}

                    {activeReportTab === 'sources' && (
                      <motion.div 
                        key="sources"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        className="bg-white/[0.02] border border-white/5 rounded-[3rem] p-10 backdrop-blur-3xl"
                      >
                        <h4 className="text-[10px] font-black text-gray-500 uppercase tracking-[0.3em] mb-10 flex items-center gap-3 italic">
                          <Globe size={16} /> {t.intelligenceSources}
                        </h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                          {result.sources.length > 0 ? result.sources.map((source, idx) => (
                            <a
                              key={idx}
                              href={source.uri}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex items-center justify-between p-5 rounded-3xl bg-white/5 hover:bg-white/10 border border-white/5 transition-all group"
                            >
                              <div className="flex flex-col min-w-0">
                                <span className="text-[10px] font-black text-white truncate uppercase tracking-wider mb-1">{source.title}</span>
                                <span className="text-[9px] text-gray-600 truncate font-mono italic">{new URL(source.uri).hostname}</span>
                              </div>
                              <div className="p-2 bg-white/5 rounded-lg group-hover:bg-blue-500/20 transition-colors">
                                <ExternalLink size={12} className="text-gray-700 group-hover:text-blue-500" />
                              </div>
                            </a>
                          )) : (
                            <div className="col-span-full text-center py-20 text-gray-700 italic text-[10px] font-black uppercase tracking-widest">
                              {t.noSources}
                            </div>
                          )}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </motion.div>
          ) : null}
        </AnimatePresence>

        {/* Lab and Stats */}
        {!isSearching && !result && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-48 border-t border-white/5 pt-24">
            <div className="col-span-2 space-y-12">
              {/* Nexus Lab Section */}
              <div>
                <div className="flex items-center justify-between mb-8">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse" />
                    <h3 className="text-[10px] font-black uppercase tracking-[0.3em] text-white/50 italic">{t.labTitle}</h3>
                  </div>
                  <button 
                    onClick={() => setShowLab(!showLab)}
                    className="text-[9px] font-black text-blue-500 uppercase tracking-widest hover:underline"
                  >
                    {showLab ? 'Hide Lab' : 'Show All Tools'}
                  </button>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {[
                    { id: 'dorks', name: t.labDorks, icon: <FileSearch size={18} />, desc: 'Advanced Google Dorking' },
                    { id: 'metadata', name: t.labMetadata, icon: <Layers size={18} />, desc: 'EXIF & File Analysis' },
                    { id: 'headers', name: t.labHeaders, icon: <FileType size={18} />, desc: 'Email Header Deep-Dive' },
                    { id: 'password', name: t.labPassword, icon: <Lock size={18} />, desc: 'Leak & Strength Check' }
                  ].map((tool) => (
                    <motion.div 
                      key={tool.id}
                      whileHover={{ scale: 1.02, backgroundColor: 'rgba(255,255,255,0.05)' }}
                      className="p-6 bg-white/[0.02] border border-white/5 rounded-[2rem] cursor-pointer transition-all group"
                    >
                      <div className="flex items-center gap-4 mb-3">
                        <div className="p-3 bg-cyan-500/10 rounded-xl text-cyan-400 group-hover:bg-cyan-500/20 transition-all">
                          {tool.icon}
                        </div>
                        <h4 className="text-[11px] font-black text-white uppercase tracking-wider">{tool.name}</h4>
                      </div>
                      <p className="text-[9px] text-gray-600 uppercase font-bold tracking-widest">{tool.desc}</p>
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Live Feed */}
              <div>
                <div className="flex items-center gap-3 mb-8">
                  <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
                  <h3 className="text-[10px] font-black uppercase tracking-[0.3em] text-white/50 italic">{t.liveFeed}</h3>
                </div>
                <div className="space-y-4">
                  {liveEvents.map((event) => (
                    <motion.div 
                      key={event.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="flex items-center justify-between p-5 bg-white/[0.02] border border-white/5 rounded-3xl hover:bg-white/[0.04] transition-all"
                    >
                      <div className="flex items-center gap-5">
                        <div className="p-2 bg-blue-500/5 rounded-lg">
                          <Terminal size={14} className="text-blue-500/60" />
                        </div>
                        <span className="text-[11px] font-mono text-gray-400 tracking-tight">{event.text}</span>
                      </div>
                      <span className="text-[9px] font-mono text-gray-700 uppercase tracking-widest">{event.time}</span>
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="space-y-8">
              {/* Dark Web Monitor Widget */}
              <div className="bg-red-600/[0.03] border border-red-500/10 rounded-[3rem] p-10 relative overflow-hidden group">
                <div className="absolute -top-24 -right-24 w-64 h-64 bg-red-500/5 rounded-full blur-3xl group-hover:bg-red-500/10 transition-all" />
                <div className="relative z-10">
                  <div className="flex items-center justify-between mb-8">
                    <h3 className="text-[10px] font-black uppercase tracking-[0.3em] text-red-400/60 italic">{t.monitorTitle}</h3>
                    <div className="flex items-center gap-2 px-2 py-1 bg-red-500/10 rounded-full border border-red-500/20">
                      <div className="w-1 h-1 rounded-full bg-red-500 animate-ping" />
                      <span className="text-[7px] font-black text-red-500 uppercase tracking-widest">{t.monitorActive}</span>
                    </div>
                  </div>
                  <div className="space-y-4 mb-8">
                    {[
                      { label: 'Active Watches', value: '12' },
                      { label: 'New Hits (24h)', value: '0' },
                      { label: 'Security Level', value: 'MAX' }
                    ].map((s, i) => (
                      <div key={i} className="flex items-center justify-between">
                        <span className="text-[9px] font-black text-gray-600 uppercase tracking-widest">{s.label}</span>
                        <span className="text-[10px] font-black text-white uppercase tracking-widest">{s.value}</span>
                      </div>
                    ))}
                  </div>
                  <button className="w-full py-4 bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 rounded-2xl text-[9px] font-black text-red-400 uppercase tracking-[0.2em] transition-all">
                    Configure Watchlist
                  </button>
                </div>
              </div>

              {/* Leak Detection Stats */}
              <div className="bg-blue-600/[0.03] border border-blue-500/10 rounded-[3rem] p-10 flex flex-col justify-between relative overflow-hidden group">
              <div className="absolute -top-24 -right-24 w-64 h-64 bg-blue-500/5 rounded-full blur-3xl group-hover:bg-blue-500/10 transition-all" />
              <div>
                <h3 className="text-[10px] font-black uppercase tracking-[0.3em] text-blue-400/60 mb-8 italic">{t.leakDetection}</h3>
                <div className="flex items-center gap-6 mb-10">
                  <div className="p-4 bg-blue-500/10 rounded-2xl border border-blue-500/20">
                    <ShieldAlert size={28} className="text-blue-500" />
                  </div>
                  <div>
                    <div className="text-3xl font-black text-white tracking-tighter italic">14.2B+</div>
                    <div className="text-[9px] font-black text-gray-600 uppercase tracking-[0.2em]">Records Indexed</div>
                  </div>
                </div>
              </div>
              <div className="space-y-5">
                <div className="flex items-center justify-between text-[10px] font-black uppercase tracking-widest">
                  <span className="text-gray-500">Global Coverage</span>
                  <span className="text-blue-400">98.4%</span>
                </div>
                <div className="w-full h-2 bg-white/5 rounded-full overflow-hidden border border-white/5">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: '98.4%' }}
                    transition={{ duration: 2, delay: 0.5 }}
                    className="h-full bg-gradient-to-r from-blue-600 to-blue-400 shadow-[0_0_15px_rgba(59,130,246,0.3)]" 
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        )}

        {/* History Section */}
        {!isSearching && !result && history.length > 0 && (
          <motion.section
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mt-32 max-w-4xl mx-auto"
          >
            <div className="flex items-center justify-between mb-10">
              <div className="flex items-center gap-4">
                <button 
                  onClick={() => setCompareMode(!compareMode)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl border transition-all text-[10px] font-black uppercase tracking-widest ${
                    compareMode ? 'bg-blue-600 border-blue-400 text-white shadow-lg shadow-blue-600/20' : 'bg-white/5 border-white/10 text-gray-500 hover:text-gray-300'
                  }`}
                >
                  <ArrowRightLeft size={14} />
                  {t.compareTitle}
                </button>
                <div className="flex gap-2">
                  <button 
                    onClick={() => setShowStarredOnly(false)}
                    className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest transition-all ${!showStarredOnly ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' : 'text-gray-600 hover:text-gray-400'}`}
                  >
                    All
                  </button>
                  <button 
                    onClick={() => setShowStarredOnly(true)}
                    className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest transition-all ${showStarredOnly ? 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20' : 'text-gray-600 hover:text-gray-400'}`}
                  >
                    {t.starred}
                  </button>
                </div>
              </div>
              <button 
                onClick={() => {
                  if (confirm('Clear all history?')) {
                    localStorage.removeItem('osint_lookup_history_v2');
                    setHistory([]);
                  }
                }}
                className="p-2 bg-white/5 hover:bg-red-500/10 border border-white/10 hover:border-red-500/20 rounded-xl text-gray-500 hover:text-red-500 transition-all"
                title={t.clearArchives}
              >
                <Trash2 size={14} />
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {history.filter(item => !showStarredOnly || item.isStarred).map((item, idx) => (
                <div key={item.id || idx} className="group relative">
                  <button
                    onClick={() => {
                      setQuery(item.query);
                      handleSearch(undefined, item.query);
                    }}
                    className="w-full flex items-center justify-between p-6 bg-white/[0.01] hover:bg-white/[0.03] rounded-3xl border border-white/5 hover:border-blue-500/30 transition-all text-left relative overflow-hidden"
                  >
                    <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                      {item.type === 'phone' && <Phone size={40} />}
                      {item.type === 'email' && <Mail size={40} />}
                      {item.type === 'telegram' && <Send size={40} />}
                      {item.type === 'ip' && <Globe size={40} />}
                      {item.type === 'username' && <User size={40} />}
                      {item.type === 'domain' && <Globe size={40} />}
                      {item.type === 'crypto' && <Fingerprint size={40} />}
                      {item.type === 'vehicle' && <Activity size={40} />}
                    </div>
                    <div className="flex items-center gap-5 min-w-0 relative z-10">
                      {compareMode && (
                        <div 
                          onClick={(e) => e.stopPropagation()}
                          className="relative z-30"
                        >
                          <input 
                            type="checkbox" 
                            checked={compareItems.includes(item.id)}
                            onChange={(e) => {
                              if (e.target.checked) setCompareItems([...compareItems, item.id]);
                              else setCompareItems(compareItems.filter(id => id !== item.id));
                            }}
                            className="w-5 h-5 rounded-lg border-white/10 bg-white/5 text-blue-600 focus:ring-blue-500 cursor-pointer"
                          />
                        </div>
                      )}
                      <div className="p-4 bg-white/5 rounded-2xl text-gray-600 group-hover:text-blue-500 transition-colors border border-white/5">
                        {item.type === 'phone' && <Phone size={20} />}
                        {item.type === 'email' && <Mail size={20} />}
                        {item.type === 'telegram' && <Send size={20} />}
                        {item.type === 'ip' && <Globe size={20} />}
                        {item.type === 'username' && <User size={20} />}
                        {item.type === 'domain' && <Globe size={20} />}
                        {item.type === 'crypto' && <Fingerprint size={20} />}
                        {item.type === 'vehicle' && <Activity size={20} />}
                        {item.type === 'face' && <Camera size={20} />}
                        {item.type === 'mac' && <Cpu size={20} />}
                        {item.type === 'company' && <Briefcase size={20} />}
                        {item.type === 'passport' && <CreditCard size={20} />}
                        {item.type === 'auto' && <Fingerprint size={20} />}
                      </div>
                      <div className="min-w-0">
                        <p className="text-white font-black text-lg truncate tracking-tighter italic">{item.query}</p>
                        <p className="text-[10px] text-gray-600 font-bold uppercase tracking-widest mt-1">{item.timestamp}</p>
                      </div>
                    </div>
                  </button>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleStar(item.id);
                    }}
                    className={`absolute top-4 right-4 p-2 rounded-xl transition-all z-20 ${item.isStarred ? 'text-yellow-500 bg-yellow-500/10' : 'text-gray-700 hover:text-gray-500 bg-white/5 opacity-0 group-hover:opacity-100'}`}
                  >
                    <Zap size={14} fill={item.isStarred ? "currentColor" : "none"} />
                  </button>
                </div>
              ))}
            </div>
          </motion.section>
        )}
      </main>

      {/* Comparison Overlay */}
      <AnimatePresence>
        {compareMode && compareItems.length >= 2 && (
          <motion.div 
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 100 }}
            className="fixed bottom-12 left-1/2 -translate-x-1/2 z-50 w-full max-w-2xl px-6"
          >
            <div className="bg-blue-600 rounded-[2.5rem] p-8 shadow-2xl shadow-blue-600/40 flex items-center justify-between border border-blue-400/30 backdrop-blur-xl">
              <div className="flex items-center gap-6">
                <div className="flex -space-x-4">
                  {compareItems.map((id, i) => {
                    const item = history.find(h => h.id === id);
                    return (
                      <div key={id} className="w-12 h-12 rounded-full bg-white/10 border-2 border-blue-600 flex items-center justify-center text-white text-xs font-black backdrop-blur-md">
                        {item?.query[0].toUpperCase()}
                      </div>
                    );
                  })}
                </div>
                <div>
                  <h5 className="text-white font-black text-lg tracking-tighter uppercase italic">{t.compareTitle}</h5>
                  <p className="text-blue-100 text-[10px] font-bold uppercase tracking-widest">{compareItems.length} items selected</p>
                </div>
              </div>
              <div className="flex gap-3">
                <button 
                  onClick={() => setCompareItems([])}
                  className="px-6 py-3 rounded-2xl bg-white/10 hover:bg-white/20 text-white text-[10px] font-black uppercase tracking-widest transition-all"
                >
                  Reset
                </button>
                <button 
                  onClick={() => {
                    const items = history.filter(h => compareItems.includes(h.id));
                    alert(`Comparing: ${items.map(i => i.query).join(' vs ')}\n\n(Comparison logic would generate a side-by-side report here)`);
                  }}
                  className="px-8 py-3 rounded-2xl bg-white text-blue-600 text-[10px] font-black uppercase tracking-widest transition-all shadow-xl hover:scale-105 active:scale-95"
                >
                  Analyze
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Lab Tool Modal (Simulated) */}
      <AnimatePresence>
        {showLab && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-[#050506]/90 backdrop-blur-xl"
            onClick={() => setShowLab(false)}
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-[#0A0A0C] border border-white/10 rounded-[3rem] p-12 max-w-4xl w-full shadow-2xl relative overflow-hidden"
              onClick={e => e.stopPropagation()}
            >
              <div className="absolute top-0 right-0 p-12 opacity-5 pointer-events-none">
                <FlaskConical size={300} />
              </div>
              
              <div className="relative z-10">
                <div className="flex items-center justify-between mb-12">
                  <div className="flex items-center gap-4">
                    <div className="p-4 bg-cyan-500/20 rounded-2xl border border-cyan-500/30">
                      <FlaskConical size={32} className="text-cyan-400" />
                    </div>
                    <div>
                      <h4 className="text-3xl font-black text-white tracking-tighter uppercase italic">{t.labTitle}</h4>
                      <p className="text-[10px] font-black text-cyan-500/60 uppercase tracking-[0.3em]">Experimental Intelligence Utilities</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setShowLab(false)}
                    className="p-4 bg-white/5 hover:bg-white/10 rounded-2xl text-gray-500 transition-all"
                  >
                    <Trash2 size={20} />
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {[
                    { title: t.labDorks, icon: <FileSearch />, desc: 'Generate complex search queries for Google, Bing, and Yandex to find hidden files and directories.' },
                    { title: t.labMetadata, icon: <Layers />, desc: 'Upload images or documents to extract hidden EXIF data, GPS coordinates, and software versions.' },
                    { title: t.labHeaders, icon: <FileType />, desc: 'Paste raw email headers to trace the origin IP, mail servers, and authentication status.' },
                    { title: t.labPassword, icon: <Lock />, desc: 'Check if a password has been compromised in known data breaches (HIBP integration).' }
                  ].map((tool, i) => (
                    <div key={i} className="p-8 bg-white/[0.02] border border-white/5 rounded-[2rem] hover:border-cyan-500/30 transition-all group">
                      <div className="flex items-center gap-4 mb-4">
                        <div className="p-3 bg-white/5 rounded-xl text-cyan-400 group-hover:bg-cyan-500/20 transition-all">
                          {tool.icon}
                        </div>
                        <h5 className="text-lg font-black text-white uppercase tracking-tight italic">{tool.title}</h5>
                      </div>
                      <p className="text-xs text-gray-500 leading-relaxed font-medium mb-6">{tool.desc}</p>
                      <button className="w-full py-3 bg-white/5 hover:bg-cyan-500/20 border border-white/10 hover:border-cyan-500/30 rounded-xl text-[9px] font-black text-gray-400 group-hover:text-cyan-400 uppercase tracking-widest transition-all">
                        Launch Utility
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <footer className="relative z-10 max-w-6xl mx-auto px-6 py-20 border-t border-white/5">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <Fingerprint size={24} className="text-blue-500" />
              <span className="font-black text-white tracking-tighter italic uppercase">{t.title} Intelligence</span>
            </div>
            <p className="text-gray-600 text-[10px] font-medium max-w-xs leading-relaxed uppercase tracking-wider">
              {t.footerDesc}
            </p>
          </div>
          <div className="flex flex-col md:items-end gap-4">
            <div className="flex items-center gap-3 text-gray-700 text-[10px] font-black uppercase tracking-[0.3em]">
              <Terminal size={14} />
              <span>{t.engineVersion}</span>
            </div>
            <p className="text-gray-700 text-[9px] font-black uppercase tracking-widest">
              © {new Date().getFullYear()} Nexus Intelligence Systems. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
